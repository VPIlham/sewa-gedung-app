const LandingController = require("./LandingController");
const AdminController = require("./AdminController");

module.exports = {
  LandingController,
  AdminController,
};
